# Healing Blood Automation

Módulo para Foundry VTT v14 que automatiza a técnica **Healing Blood**.

## Versão 1.0.1

- O contador de dano agora usa `dnd5e.damageActor`, que detecta perda de PV por qualquer meio processado pelo sistema D&D5e.
- `dnd5e.applyDamage` permanece apenas para tentar identificar o atacante corpo a corpo.
- No fim de cada turno, o portador recupera metade do dano acumulado + modificador de Agilidade.
- O Active Effect deve se chamar exatamente `Healing Blood`.

## Importante sobre Pained Healing

Na macro Pained Healing, remova o trecho que soma manualmente `healingBloodDamage`. A versão 1.0.1 detecta a perda de PV automaticamente; manter a soma manual pode contar o sacrifício duas vezes.
