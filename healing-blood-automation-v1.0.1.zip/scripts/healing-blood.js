const HB_EFFECT_NAME = "Healing Blood";
const HB_FLAG_DAMAGE = "healingBloodDamage";
const HB_FLAG_SCOPE = "world";

function hasHealingBlood(actor) {
  if (!actor) return false;
  return actor.effects.some(effect =>
    !effect.disabled &&
    effect.name?.toLowerCase() === HB_EFFECT_NAME.toLowerCase()
  );
}

function getHP(actor) {
  return {
    value: Number(foundry.utils.getProperty(actor, "system.attributes.hp.value")) || 0,
    max: Number(foundry.utils.getProperty(actor, "system.attributes.hp.max")) || 0
  };
}

async function healActor(actor, amount) {
  if (!actor) return 0;
  amount = Math.max(0, Number(amount) || 0);

  const hp = getHP(actor);
  const missing = Math.max(0, hp.max - hp.value);
  const effective = Math.min(amount, missing);

  if (effective <= 0) return 0;

  await actor.update({
    "system.attributes.hp.value": hp.value + effective
  });

  return effective;
}

async function accumulateDamage(actor, amount) {
  if (!actor) return;

  amount = Math.max(0, Number(amount) || 0);
  if (amount <= 0) return;

  const current =
    Number(actor.getFlag(HB_FLAG_SCOPE, HB_FLAG_DAMAGE)) || 0;

  await actor.setFlag(
    HB_FLAG_SCOPE,
    HB_FLAG_DAMAGE,
    current + amount
  );

  console.log(
    `Healing Blood | ${actor.name}: +${amount} dano acumulado (${current + amount} total).`
  );
}

async function clearDamage(actor) {
  if (!actor) return;
  try {
    await actor.unsetFlag(HB_FLAG_SCOPE, HB_FLAG_DAMAGE);
  } catch (_) {}
}

Hooks.once("ready", () => {
  if (globalThis.HealingBloodAutomation?.active) {
    console.log("Healing Blood | Automação já carregada.");
    return;
  }

  console.log("Healing Blood | Iniciando automação v1.0.1...");

  // =========================================================
  // CONTADOR DE DANO
  // =========================================================
  // dnd5e.damageActor é disparado sempre que os PV diminuem,
  // independentemente de o dano ter vindo de Apply Damage,
  // atividade, macro ou outra alteração processada pelo D&D5e.
  //
  // Importante: Pained Healing NÃO deve somar manualmente a flag
  // healingBloodDamage quando esta versão do módulo estiver ativa,
  // ou o sacrifício poderá ser contado duas vezes.
  // =========================================================

  const actorDamageHook = Hooks.on(
    "dnd5e.damageActor",
    async (actor, changes = {}, update = {}, userId) => {
      if (!game.user.isGM) return;
      if (!actor) return;
      if (!hasHealingBlood(actor)) return;

      // No hook damageActor, as alterações de PV são negativas.
      // total inclui PV e PV temporários; para Healing Blood,
      // queremos a perda total efetiva.
      let amount = Math.abs(Number(changes?.total) || 0);

      // Fallback caso "total" não esteja disponível.
      if (amount <= 0) {
        const hpLoss = Math.min(0, Number(changes?.hp) || 0);
        const tempLoss = Math.min(0, Number(changes?.temp) || 0);
        amount = Math.abs(hpLoss + tempLoss);
      }

      if (amount <= 0) return;

      await accumulateDamage(actor, amount);
    }
  );

  // =========================================================
  // CURA DE QUEM ATACA CORPO A CORPO
  // =========================================================
  // applyDamage continua sendo usado somente para tentar
  // identificar a origem/atacante. Ele NÃO soma o dano aqui,
  // evitando contar o mesmo dano duas vezes.
  // =========================================================

  const applyDamageHook = Hooks.on(
    "dnd5e.applyDamage",
    async (actor, amount, options = {}) => {
      if (!game.user.isGM) return;
      if (!actor) return;
      if (!hasHealingBlood(actor)) return;

      amount = Math.max(0, Number(amount) || 0);
      if (amount <= 0) return;

      let attacker =
        options?.sourceActor ??
        options?.source?.actor ??
        options?.actor ??
        null;

      let item =
        options?.item ??
        options?.sourceItem ??
        options?.source?.item ??
        null;

      if (typeof attacker === "string") {
        try {
          attacker = await fromUuid(attacker);
        } catch (_) {
          attacker = null;
        }
      }

      if (typeof item === "string") {
        try {
          item = await fromUuid(item);
        } catch (_) {
          item = null;
        }
      }

      if (!attacker) return;

      // Se vier Token/TokenDocument, resolve para Actor.
      if (attacker.actor) attacker = attacker.actor;

      let actionType =
        item?.system?.actionType ??
        options?.activity?.actionType ??
        options?.activity?.system?.actionType ??
        null;

      if (!actionType && item) {
        const activities = item.system?.activities;
        const firstActivity =
          activities?.contents?.[0] ??
          activities?.[0] ??
          null;

        actionType =
          firstActivity?.actionType ??
          firstActivity?.system?.actionType ??
          firstActivity?.type ??
          null;
      }

      const isMelee = ["mwak", "msak"].includes(actionType);
      if (!isMelee) return;

      const dice = Math.floor(amount / 7);
      if (dice <= 0) return;

      const roll = await new Roll(`${dice}d4`).evaluate();
      const effectiveHealing =
        await healActor(attacker, roll.total);

      await roll.toMessage({
        speaker: ChatMessage.getSpeaker({ actor: attacker }),
        flavor:
          `<b>Healing Blood</b><br>` +
          `${attacker.name} causou <b>${amount} de dano corpo a corpo</b> em ${actor.name}.<br>` +
          `Healing Blood concede <b>${dice}d4</b> de cura.<br>` +
          `Cura efetiva: <b>${effectiveHealing} PV</b>.`
      });
    }
  );

  // =========================================================
  // FIM DE QUALQUER TURNO
  // =========================================================

  const combatHook = Hooks.on(
    "updateCombat",
    async (combat, changed) => {
      if (!game.user.isGM) return;

      const turnChanged =
        Object.prototype.hasOwnProperty.call(changed, "turn");

      const roundChanged =
        Object.prototype.hasOwnProperty.call(changed, "round");

      if (!turnChanged && !roundChanged) return;

      const processedActors = new Set();

      for (const combatant of combat.combatants) {
        const actor = combatant.actor;
        if (!actor) continue;
        if (processedActors.has(actor.id)) continue;

        processedActors.add(actor.id);

        if (!hasHealingBlood(actor)) continue;

        const damage =
          Number(actor.getFlag(HB_FLAG_SCOPE, HB_FLAG_DAMAGE)) || 0;

        if (damage <= 0) continue;

        const dexMod =
          Number(
            foundry.utils.getProperty(
              actor,
              "system.abilities.dex.mod"
            )
          ) || 0;

        const halfDamage = Math.floor(damage / 2);
        const healing = Math.max(0, halfDamage + dexMod);

        const effectiveHealing =
          await healActor(actor, healing);

        await clearDamage(actor);

        await ChatMessage.create({
          speaker: ChatMessage.getSpeaker({ actor }),
          content:
            `<div class="chat-card">` +
            `<h2>Healing Blood</h2>` +
            `<p><b>${actor.name}</b> sofreu <b>${damage} de dano</b> durante o turno.</p>` +
            `<p>Metade do dano: <b>${halfDamage}</b><br>` +
            `Mod. Agilidade: <b>${dexMod >= 0 ? "+" : ""}${dexMod}</b></p>` +
            `<hr><p>Recupera <b>${effectiveHealing} PV</b>.</p>` +
            `</div>`
        });
      }
    }
  );

  // =========================================================
  // LIMPA O CONTADOR QUANDO HEALING BLOOD É DESATIVADO/REMOVIDO
  // =========================================================

  const effectUpdateHook = Hooks.on(
    "updateActiveEffect",
    async (effect, changed) => {
      if (!game.user.isGM) return;

      const actor = effect.parent;
      if (!actor) return;

      if (
        effect.name?.toLowerCase() !==
        HB_EFFECT_NAME.toLowerCase()
      ) return;

      if (changed.disabled === true) {
        await clearDamage(actor);
      }
    }
  );

  const effectDeleteHook = Hooks.on(
    "deleteActiveEffect",
    async effect => {
      if (!game.user.isGM) return;

      const actor = effect.parent;
      if (!actor) return;

      if (
        effect.name?.toLowerCase() !==
        HB_EFFECT_NAME.toLowerCase()
      ) return;

      await clearDamage(actor);
    }
  );

  globalThis.HealingBloodAutomation = {
    active: true,
    version: "1.0.1",
    actorDamageHook,
    applyDamageHook,
    combatHook,
    effectUpdateHook,
    effectDeleteHook
  };

  ui.notifications.info(
    "Healing Blood Automation v1.0.1 carregada."
  );

  console.log(
    "Healing Blood | Automação v1.0.1 ativa."
  );
});
