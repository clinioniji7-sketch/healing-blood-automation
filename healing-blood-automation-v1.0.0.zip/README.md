# Healing Blood Automation

Módulo para Foundry VTT v14 / D&D5e.

- Requer um Active Effect chamado exatamente `Healing Blood`.
- Acumula todo dano recebido enquanto o efeito estiver ativo.
- Ao fim de cada turno, cura `floor(dano acumulado / 2) + Mod. Agilidade`.
- Limpa o contador ao desativar/remover o efeito.
- Tenta curar atacantes corpo a corpo em `1d4` para cada 7 de dano causado.

## Instalação por Manifest

Use o `module.json` da raiz como Manifest URL no Foundry.
